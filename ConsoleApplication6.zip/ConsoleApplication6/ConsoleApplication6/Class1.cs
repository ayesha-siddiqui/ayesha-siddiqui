﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Class1
    {
        public const int INF = 99999;

        public  void printing(int[,] dis, int vertices)
        {
            Console.WriteLine("Shortest distances between every pair of vertices:");

            for (int i = 0; i < vertices; ++i)
            {
                for (int j = 0; j < vertices; ++j)
                {
                    if (dis[i, j] == INF)
                        Console.Write("INF".PadLeft(7));
                    else
                        Console.Write(dis[i, j].ToString().PadLeft(7));
                }

                Console.WriteLine();
            }
        }

        public  void logic(int[,] g, int vertices)
        {
            int[,] dis = new int[vertices, vertices];

            for (int i = 0; i < vertices; ++i)
                for (int j = 0; j < vertices; ++j)
                    dis[i, j] = g[i, j];

            for (int k = 0; k < vertices; ++k)
            {
                for (int i = 0; i < vertices; ++i)
                {
                    for (int j = 0; j < vertices; ++j)
                    {
                        if (dis[i, k] + dis[k, j] < dis[i, j])
                            dis[i, j] = dis[i, k] + dis[k, j];
                    }
                }
            }

            printing(dis, vertices);
        }

    }
}

